import java.lang.System;
import ruixue.srilm;

public class runme {
   static {
       System.loadLibrary("srilm.so");
   }
   
   public static void main(String argv[]) {
       System.out.println(srlim.getIndexForWord(1f));
   }
}
